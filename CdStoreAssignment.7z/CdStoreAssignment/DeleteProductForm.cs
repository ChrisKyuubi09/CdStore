﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CdStoreAssignment
{
	public partial class DeleteProductForm : Form
	{
		public DeleteProductForm()
		{
			InitializeComponent();
		}

		private void DeleteProductForm_Load(object sender, EventArgs e)
		{
			// TODO: This line of code loads data into the 'cdStoreDataSet1.Cds' table. You can move, or remove it, as needed.
			this.cdsTableAdapter.Fill(this.cdStoreDataSet1.Cds);

		}

		private void button1_Click(object sender, EventArgs e)
		{
			if (radioButton1.Checked)
			{
				//Step 1
				SqlConnection con = new SqlConnection("Data Source=DESKTOP-BVQ14LQ\\SQLEXPRESS;Initial Catalog=CdStore;Integrated Security=True");
				
				//Step 2
				string query = "delete from Cds where id='" + comboBox1.SelectedValue + "'";

				string id = comboBox1.SelectedValue.ToString();
				string query2 = "select album from Cds where id='"+id+"'";

				string albumName = "";

				//Step 3
				SqlCommand command = new SqlCommand(query, con);
				SqlCommand command2 = new SqlCommand(query2, con);

				//Step 4
				try
				{
					con.Open();
					albumName=command2.ExecuteScalar().ToString();
					command.ExecuteNonQuery();
					con.Close();
					MessageBox.Show(albumName + " album was deleted successfully");
				}
				catch (Exception ex)
				{
					con.Close();
					MessageBox.Show("Something went wrong");
				}

			}
			else if (radioButton2.Checked)
			{
				MessageBox.Show("Please select Yes to delete album");
			}
			else
			{
				MessageBox.Show("Please select one from the options or press Go Back");
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			Products p = new Products();
			p.Show();
			this.Hide();
		}
	}
}
