﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CdStoreAssignment
{
	public partial class DeleteSaleForm : Form
	{
		public DeleteSaleForm()
		{
			InitializeComponent();
		}

		private void DeleteSaleForm_Load(object sender, EventArgs e)
		{
			SqlConnection con = new SqlConnection("Data Source=DESKTOP-BVQ14LQ\\SQLEXPRESS;Initial Catalog=CdStore;Integrated Security=True");

			SqlDataAdapter dataAdapter = new SqlDataAdapter(@"SELECT dbo.Customers.Id, dbo.Customers.Name, dbo.Customers.Surname, dbo.Cds.Album, dbo.Cds.Price, dbo.Cds.Storage, dbo.Sales.saleDate FROM dbo.Cds INNER JOIN dbo.Sales ON dbo.Cds.Id = dbo.Sales.idCd INNER JOIN dbo.Customers ON dbo.Sales.idCustomer = dbo.Customers.Id", con);

			DataTable dt = new DataTable();
			dataAdapter.Fill(dt);

			dataGridView1.DataSource = dt;
		}

		private void button2_Click(object sender, EventArgs e)
		{
			Sales s = new Sales();
			s.Show();
			this.Hide();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			string selectedSale = dataGridView1.CurrentRow.Cells["id"].Value.ToString();

			SqlConnection con = new SqlConnection("Data Source=DESKTOP-BVQ14LQ\\SQLEXPRESS;Initial Catalog=CdStore;Integrated Security=True");

			string query="delete from Sales where idCustomer='"+selectedSale+"'";
			SqlCommand command = new SqlCommand(query, con);

			try 
			{
				con.Open();

				command.ExecuteNonQuery();

				con.Close();
			}
			catch (Exception ex) 
			{
				con.Close();
				MessageBox.Show(ex.ToString());
			}

			//Refresh the datagridview
			SqlConnection con2 = new SqlConnection("Data Source=DESKTOP-BVQ14LQ\\SQLEXPRESS;Initial Catalog=CdStore;Integrated Security=True");

			SqlDataAdapter dataAdapter = new SqlDataAdapter(@"SELECT dbo.Customers.Id, dbo.Customers.Name, dbo.Customers.Surname, dbo.Cds.Album, dbo.Cds.Price, dbo.Cds.Storage, dbo.Sales.saleDate FROM dbo.Cds INNER JOIN dbo.Sales ON dbo.Cds.Id = dbo.Sales.idCd INNER JOIN dbo.Customers ON dbo.Sales.idCustomer = dbo.Customers.Id", con);

			DataTable dt = new DataTable();
			dataAdapter.Fill(dt);

			dataGridView1.DataSource = dt;
		}
	}
}
