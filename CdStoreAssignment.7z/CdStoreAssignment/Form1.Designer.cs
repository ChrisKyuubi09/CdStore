﻿namespace CdStoreAssignment
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.managmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.customersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.insertCustomerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.updateCustomerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.deleteCustomerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.productsCdsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.insertNewCdAlbumToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.updateCdAlbumToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.deleteCdAlbumToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.salesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.newSaleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.updateSaleRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.deleteSalreRecordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.exitApplicationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.button1 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.statusStrip1 = new System.Windows.Forms.StatusStrip();
			this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.menuStrip1.SuspendLayout();
			this.statusStrip1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.SuspendLayout();
			// 
			// menuStrip1
			// 
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.managmentToolStripMenuItem,
            this.exitApplicationToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(800, 24);
			this.menuStrip1.TabIndex = 1;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// managmentToolStripMenuItem
			// 
			this.managmentToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.customersToolStripMenuItem,
            this.productsCdsToolStripMenuItem,
            this.salesToolStripMenuItem});
			this.managmentToolStripMenuItem.Name = "managmentToolStripMenuItem";
			this.managmentToolStripMenuItem.Size = new System.Drawing.Size(84, 20);
			this.managmentToolStripMenuItem.Text = "Managment";
			// 
			// customersToolStripMenuItem
			// 
			this.customersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.insertCustomerToolStripMenuItem,
            this.updateCustomerToolStripMenuItem,
            this.deleteCustomerToolStripMenuItem});
			this.customersToolStripMenuItem.Name = "customersToolStripMenuItem";
			this.customersToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
			this.customersToolStripMenuItem.Text = "Customers";
			this.customersToolStripMenuItem.Click += new System.EventHandler(this.customersToolStripMenuItem_Click);
			// 
			// insertCustomerToolStripMenuItem
			// 
			this.insertCustomerToolStripMenuItem.Name = "insertCustomerToolStripMenuItem";
			this.insertCustomerToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
			this.insertCustomerToolStripMenuItem.Text = "Insert Customer";
			this.insertCustomerToolStripMenuItem.Click += new System.EventHandler(this.insertCustomerToolStripMenuItem_Click);
			// 
			// updateCustomerToolStripMenuItem
			// 
			this.updateCustomerToolStripMenuItem.Name = "updateCustomerToolStripMenuItem";
			this.updateCustomerToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
			this.updateCustomerToolStripMenuItem.Text = "Update Customer";
			this.updateCustomerToolStripMenuItem.Click += new System.EventHandler(this.updateCustomerToolStripMenuItem_Click);
			// 
			// deleteCustomerToolStripMenuItem
			// 
			this.deleteCustomerToolStripMenuItem.Name = "deleteCustomerToolStripMenuItem";
			this.deleteCustomerToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
			this.deleteCustomerToolStripMenuItem.Text = "Delete Customer";
			this.deleteCustomerToolStripMenuItem.Click += new System.EventHandler(this.deleteCustomerToolStripMenuItem_Click);
			// 
			// productsCdsToolStripMenuItem
			// 
			this.productsCdsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.insertNewCdAlbumToolStripMenuItem,
            this.updateCdAlbumToolStripMenuItem,
            this.deleteCdAlbumToolStripMenuItem});
			this.productsCdsToolStripMenuItem.Name = "productsCdsToolStripMenuItem";
			this.productsCdsToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
			this.productsCdsToolStripMenuItem.Text = "Cd/Album";
			this.productsCdsToolStripMenuItem.Click += new System.EventHandler(this.productsCdsToolStripMenuItem_Click);
			// 
			// insertNewCdAlbumToolStripMenuItem
			// 
			this.insertNewCdAlbumToolStripMenuItem.Name = "insertNewCdAlbumToolStripMenuItem";
			this.insertNewCdAlbumToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
			this.insertNewCdAlbumToolStripMenuItem.Text = "Insert new Cd/Album";
			this.insertNewCdAlbumToolStripMenuItem.Click += new System.EventHandler(this.insertNewCdAlbumToolStripMenuItem_Click);
			// 
			// updateCdAlbumToolStripMenuItem
			// 
			this.updateCdAlbumToolStripMenuItem.Name = "updateCdAlbumToolStripMenuItem";
			this.updateCdAlbumToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
			this.updateCdAlbumToolStripMenuItem.Text = "Update Cd/Album";
			this.updateCdAlbumToolStripMenuItem.Click += new System.EventHandler(this.updateCdAlbumToolStripMenuItem_Click);
			// 
			// deleteCdAlbumToolStripMenuItem
			// 
			this.deleteCdAlbumToolStripMenuItem.Name = "deleteCdAlbumToolStripMenuItem";
			this.deleteCdAlbumToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
			this.deleteCdAlbumToolStripMenuItem.Text = "Delete Cd/Album";
			this.deleteCdAlbumToolStripMenuItem.Click += new System.EventHandler(this.deleteCdAlbumToolStripMenuItem_Click);
			// 
			// salesToolStripMenuItem
			// 
			this.salesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newSaleToolStripMenuItem,
            this.updateSaleRecordToolStripMenuItem,
            this.deleteSalreRecordToolStripMenuItem});
			this.salesToolStripMenuItem.Name = "salesToolStripMenuItem";
			this.salesToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
			this.salesToolStripMenuItem.Text = "Sales";
			this.salesToolStripMenuItem.Click += new System.EventHandler(this.salesToolStripMenuItem_Click);
			// 
			// newSaleToolStripMenuItem
			// 
			this.newSaleToolStripMenuItem.Name = "newSaleToolStripMenuItem";
			this.newSaleToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
			this.newSaleToolStripMenuItem.Text = "New Sale";
			this.newSaleToolStripMenuItem.Click += new System.EventHandler(this.newSaleToolStripMenuItem_Click);
			// 
			// updateSaleRecordToolStripMenuItem
			// 
			this.updateSaleRecordToolStripMenuItem.Name = "updateSaleRecordToolStripMenuItem";
			this.updateSaleRecordToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
			this.updateSaleRecordToolStripMenuItem.Text = "Update sale record";
			this.updateSaleRecordToolStripMenuItem.Click += new System.EventHandler(this.updateSaleRecordToolStripMenuItem_Click);
			// 
			// deleteSalreRecordToolStripMenuItem
			// 
			this.deleteSalreRecordToolStripMenuItem.Name = "deleteSalreRecordToolStripMenuItem";
			this.deleteSalreRecordToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
			this.deleteSalreRecordToolStripMenuItem.Text = "Delete salre record";
			this.deleteSalreRecordToolStripMenuItem.Click += new System.EventHandler(this.deleteSalreRecordToolStripMenuItem_Click);
			// 
			// exitApplicationToolStripMenuItem
			// 
			this.exitApplicationToolStripMenuItem.Name = "exitApplicationToolStripMenuItem";
			this.exitApplicationToolStripMenuItem.Size = new System.Drawing.Size(102, 20);
			this.exitApplicationToolStripMenuItem.Text = "Exit Application";
			this.exitApplicationToolStripMenuItem.Click += new System.EventHandler(this.exitApplicationToolStripMenuItem_Click);
			// 
			// button1
			// 
			this.button1.Font = new System.Drawing.Font("Comic Sans MS", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button1.Location = new System.Drawing.Point(169, 131);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(208, 86);
			this.button1.TabIndex = 2;
			this.button1.Text = "Customers";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// button2
			// 
			this.button2.Font = new System.Drawing.Font("Comic Sans MS", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button2.Location = new System.Drawing.Point(383, 131);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(208, 86);
			this.button2.TabIndex = 4;
			this.button2.Text = "Cd/Album";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// statusStrip1
			// 
			this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
			this.statusStrip1.Location = new System.Drawing.Point(0, 428);
			this.statusStrip1.Name = "statusStrip1";
			this.statusStrip1.Size = new System.Drawing.Size(800, 22);
			this.statusStrip1.TabIndex = 8;
			this.statusStrip1.Text = "statusStrip1";
			// 
			// toolStripStatusLabel1
			// 
			this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
			this.toolStripStatusLabel1.Size = new System.Drawing.Size(118, 17);
			this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
			this.toolStripStatusLabel1.Click += new System.EventHandler(this.toolStripStatusLabel1_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = global::CdStoreAssignment.Properties.Resources.money;
			this.pictureBox1.Location = new System.Drawing.Point(169, 223);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(422, 117);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBox1.TabIndex = 10;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click_1);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(800, 450);
			this.Controls.Add(this.pictureBox1);
			this.Controls.Add(this.statusStrip1);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.menuStrip1);
			this.IsMdiContainer = true;
			this.MainMenuStrip = this.menuStrip1;
			this.Name = "Form1";
			this.Text = "CdStoreApplication";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.statusStrip1.ResumeLayout(false);
			this.statusStrip1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem managmentToolStripMenuItem;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.ToolStripMenuItem customersToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem insertCustomerToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem updateCustomerToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem deleteCustomerToolStripMenuItem;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.ToolStripMenuItem productsCdsToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem insertNewCdAlbumToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem updateCdAlbumToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem deleteCdAlbumToolStripMenuItem;
		private System.Windows.Forms.StatusStrip statusStrip1;
		private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
		private System.Windows.Forms.ToolStripMenuItem exitApplicationToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem salesToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem newSaleToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem updateSaleRecordToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem deleteSalreRecordToolStripMenuItem;
		private System.Windows.Forms.PictureBox pictureBox1;
	}
}

