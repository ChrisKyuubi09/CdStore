﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CdStoreAssignment
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			toolStripStatusLabel1.Text ="Last logged in: "+ DateTime.Now.ToString("dddd,dd-MMMM-yyyy HH:mm");
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Customers cus = new Customers();
			cus.Show();
			this.Hide();
		}

		private void customersToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Customers cus = new Customers();
			cus.Show();
			this.Hide();
		}

		private void insertCustomerToolStripMenuItem_Click(object sender, EventArgs e)
		{
			InsertCustomerForm icf = new InsertCustomerForm();
			icf.Show();
			this.Hide();
		}

		private void updateCustomerToolStripMenuItem_Click(object sender, EventArgs e)
		{
			UpdateCustomerForm ucf = new UpdateCustomerForm();
			ucf.Show();
			this.Hide();
		}

		private void deleteCustomerToolStripMenuItem_Click(object sender, EventArgs e)
		{
			DeleteCustomerForm dcf = new DeleteCustomerForm();
			dcf.Show();
			this.Hide();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			Products pform = new Products();
			pform.Show();
			this.Hide();
		}

		private void productsCdsToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Products p = new Products();
			p.Show();
			this.Hide();
		}

		private void insertNewCdAlbumToolStripMenuItem_Click(object sender, EventArgs e)
		{
			InsertProductForm ipf = new InsertProductForm();
			ipf.Show();
			this.Hide();
		}

		private void deleteCdAlbumToolStripMenuItem_Click(object sender, EventArgs e)
		{
			DeleteProductForm dpf = new DeleteProductForm();
			dpf.Show();
			this.Hide();
		}

		private void updateCdAlbumToolStripMenuItem_Click(object sender, EventArgs e)
		{
			UpdateProductForm upf = new UpdateProductForm();
			upf.Show();
			this.Hide();
		}

		private void pictureBox1_Click(object sender, EventArgs e)
		{
			Sales s = new Sales();
			s.Show();
			this.Hide();
		}

		//this is my mistake here
		private void toolStripStatusLabel1_Click(object sender, EventArgs e)
		{
			
		}

		private void exitApplicationToolStripMenuItem_Click(object sender, EventArgs e)
		{
			System.Windows.Forms.Application.Exit();
		}

		private void salesToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Sales s = new Sales();
			s.Show();
			this.Hide();
		}

		private void newSaleToolStripMenuItem_Click(object sender, EventArgs e)
		{
			InsertSales iSales = new InsertSales();
			iSales.Show();
			this.Hide();
		}

		private void deleteSalreRecordToolStripMenuItem_Click(object sender, EventArgs e)
		{
			DeleteSaleForm dsf = new DeleteSaleForm();
			dsf.Show();
			this.Hide();
		}

		private void updateSaleRecordToolStripMenuItem_Click(object sender, EventArgs e)
		{
			UpdateSalesForm usf = new UpdateSalesForm();
			usf.Show();
			this.Hide();
		}

		private void pictureBox1_Click_1(object sender, EventArgs e)
		{
			Sales s = new Sales();
			s.Show();
			this.Hide();
		}
	}
}
