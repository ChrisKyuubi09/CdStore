﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CdStoreAssignment
{
	public partial class InsertProductForm : Form
	{
		public InsertProductForm()
		{
			InitializeComponent();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			Products p = new Products();
			p.Show();
			this.Hide();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			SqlConnection con = new SqlConnection("Data Source=DESKTOP-BVQ14LQ\\SQLEXPRESS;Initial Catalog=CdStore;Integrated Security=True");
			string query = "insert into Cds values(@cdAlbum,@cdSinger,@cdGerne,@cdPrice,@cdStorage)";
			SqlCommand command = new SqlCommand(query,con);

			command.Parameters.Add("@cdAlbum", System.Data.SqlDbType.VarChar);
			command.Parameters["@cdAlbum"].Value = textBox1.Text;

			command.Parameters.Add("@cdSinger", System.Data.SqlDbType.VarChar);
			command.Parameters["@cdSinger"].Value = textBox2.Text;

			command.Parameters.Add("@cdGerne", System.Data.SqlDbType.VarChar);
			command.Parameters["@cdGerne"].Value = textBox3.Text;

			command.Parameters.Add("@cdPrice", System.Data.SqlDbType.VarChar);
			command.Parameters["@cdPrice"].Value = textBox4.Text;

			command.Parameters.Add("@cdStorage", System.Data.SqlDbType.VarChar);
			command.Parameters["@cdStorage"].Value = textBox5.Text;

			try 
			{
				con.Open();

				command.ExecuteNonQuery();
				MessageBox.Show("New cd added successfully");

				con.Close();
			}
			catch (Exception ex) 
			{
				con.Close();
				MessageBox.Show(ex.ToString());
			}
		}
	}
}
