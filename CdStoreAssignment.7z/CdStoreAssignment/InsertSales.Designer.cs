﻿namespace CdStoreAssignment
{
	partial class InsertSales
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.button2 = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.customersBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.cdStoreDataSet = new CdStoreAssignment.CdStoreDataSet();
			this.customersTableAdapter = new CdStoreAssignment.CdStoreDataSetTableAdapters.CustomersTableAdapter();
			this.label3 = new System.Windows.Forms.Label();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.cdsBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.cdStoreDataSet1 = new CdStoreAssignment.CdStoreDataSet1();
			this.cdsTableAdapter = new CdStoreAssignment.CdStoreDataSet1TableAdapters.CdsTableAdapter();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.checkBox4 = new System.Windows.Forms.CheckBox();
			this.checkBox3 = new System.Windows.Forms.CheckBox();
			this.checkBox2 = new System.Windows.Forms.CheckBox();
			this.checkBox1 = new System.Windows.Forms.CheckBox();
			this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			this.label4 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.cdStoreDataSet)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.cdsBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.cdStoreDataSet1)).BeginInit();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(21, 447);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(102, 51);
			this.button2.TabIndex = 11;
			this.button2.Text = "< Go Back";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(12, 396);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(262, 45);
			this.button1.TabIndex = 10;
			this.button1.Text = "New Sale";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Comic Sans MS", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
			this.label1.Location = new System.Drawing.Point(12, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(375, 49);
			this.label1.TabIndex = 8;
			this.label1.Text = "Make a new sale$$$";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(18, 75);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(75, 13);
			this.label2.TabIndex = 12;
			this.label2.Text = "Customers List";
			// 
			// listBox1
			// 
			this.listBox1.DataSource = this.customersBindingSource;
			this.listBox1.DisplayMember = "Name";
			this.listBox1.FormattingEnabled = true;
			this.listBox1.Location = new System.Drawing.Point(21, 91);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new System.Drawing.Size(253, 56);
			this.listBox1.TabIndex = 13;
			this.listBox1.ValueMember = "Id";
			// 
			// customersBindingSource
			// 
			this.customersBindingSource.DataMember = "Customers";
			this.customersBindingSource.DataSource = this.cdStoreDataSet;
			// 
			// cdStoreDataSet
			// 
			this.cdStoreDataSet.DataSetName = "CdStoreDataSet";
			this.cdStoreDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			// 
			// customersTableAdapter
			// 
			this.customersTableAdapter.ClearBeforeFill = true;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(18, 159);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(54, 13);
			this.label3.TabIndex = 14;
			this.label3.Text = "Cd/Album";
			// 
			// comboBox1
			// 
			this.comboBox1.DataSource = this.cdsBindingSource;
			this.comboBox1.DisplayMember = "Album";
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Location = new System.Drawing.Point(21, 175);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(253, 21);
			this.comboBox1.TabIndex = 15;
			this.comboBox1.ValueMember = "Id";
			// 
			// cdsBindingSource
			// 
			this.cdsBindingSource.DataMember = "Cds";
			this.cdsBindingSource.DataSource = this.cdStoreDataSet1;
			// 
			// cdStoreDataSet1
			// 
			this.cdStoreDataSet1.DataSetName = "CdStoreDataSet1";
			this.cdStoreDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			// 
			// cdsTableAdapter
			// 
			this.cdsTableAdapter.ClearBeforeFill = true;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.checkBox4);
			this.groupBox1.Controls.Add(this.checkBox3);
			this.groupBox1.Controls.Add(this.checkBox2);
			this.groupBox1.Controls.Add(this.checkBox1);
			this.groupBox1.Location = new System.Drawing.Point(21, 257);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(253, 124);
			this.groupBox1.TabIndex = 16;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Procedure";
			// 
			// checkBox4
			// 
			this.checkBox4.AutoSize = true;
			this.checkBox4.Location = new System.Drawing.Point(7, 89);
			this.checkBox4.Name = "checkBox4";
			this.checkBox4.Size = new System.Drawing.Size(85, 17);
			this.checkBox4.TabIndex = 3;
			this.checkBox4.Text = "Always smile";
			this.checkBox4.UseVisualStyleBackColor = true;
			// 
			// checkBox3
			// 
			this.checkBox3.AutoSize = true;
			this.checkBox3.Location = new System.Drawing.Point(7, 66);
			this.checkBox3.Name = "checkBox3";
			this.checkBox3.Size = new System.Drawing.Size(152, 17);
			this.checkBox3.TabIndex = 2;
			this.checkBox3.Text = "Say thank you to customer";
			this.checkBox3.UseVisualStyleBackColor = true;
			// 
			// checkBox2
			// 
			this.checkBox2.AutoSize = true;
			this.checkBox2.Location = new System.Drawing.Point(7, 43);
			this.checkBox2.Name = "checkBox2";
			this.checkBox2.Size = new System.Drawing.Size(165, 17);
			this.checkBox2.TabIndex = 1;
			this.checkBox2.Text = "Ask customer for plastic back";
			this.checkBox2.UseVisualStyleBackColor = true;
			// 
			// checkBox1
			// 
			this.checkBox1.AutoSize = true;
			this.checkBox1.Location = new System.Drawing.Point(7, 20);
			this.checkBox1.Name = "checkBox1";
			this.checkBox1.Size = new System.Drawing.Size(140, 17);
			this.checkBox1.TabIndex = 0;
			this.checkBox1.Text = "Ask customer for receipt";
			this.checkBox1.UseVisualStyleBackColor = true;
			// 
			// dateTimePicker1
			// 
			this.dateTimePicker1.Location = new System.Drawing.Point(21, 215);
			this.dateTimePicker1.Name = "dateTimePicker1";
			this.dateTimePicker1.Size = new System.Drawing.Size(253, 20);
			this.dateTimePicker1.TabIndex = 17;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(18, 199);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(30, 13);
			this.label4.TabIndex = 18;
			this.label4.Text = "Date";
			// 
			// InsertSales
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(380, 510);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.dateTimePicker1);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.comboBox1);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.listBox1);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.label1);
			this.Name = "InsertSales";
			this.Text = "InsertSales";
			this.Load += new System.EventHandler(this.InsertSales_Load);
			((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.cdStoreDataSet)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.cdsBindingSource)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.cdStoreDataSet1)).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ListBox listBox1;
		private CdStoreDataSet cdStoreDataSet;
		private System.Windows.Forms.BindingSource customersBindingSource;
		private CdStoreDataSetTableAdapters.CustomersTableAdapter customersTableAdapter;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ComboBox comboBox1;
		private CdStoreDataSet1 cdStoreDataSet1;
		private System.Windows.Forms.BindingSource cdsBindingSource;
		private CdStoreDataSet1TableAdapters.CdsTableAdapter cdsTableAdapter;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.CheckBox checkBox4;
		private System.Windows.Forms.CheckBox checkBox3;
		private System.Windows.Forms.CheckBox checkBox2;
		private System.Windows.Forms.CheckBox checkBox1;
		private System.Windows.Forms.DateTimePicker dateTimePicker1;
		private System.Windows.Forms.Label label4;
	}
}