﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CdStoreAssignment
{
	public partial class InsertSales : Form
	{
		public InsertSales()
		{
			InitializeComponent();
		}

		private void InsertSales_Load(object sender, EventArgs e)
		{
			// TODO: This line of code loads data into the 'cdStoreDataSet1.Cds' table. You can move, or remove it, as needed.
			this.cdsTableAdapter.Fill(this.cdStoreDataSet1.Cds);
			// TODO: This line of code loads data into the 'cdStoreDataSet.Customers' table. You can move, or remove it, as needed.
			this.customersTableAdapter.Fill(this.cdStoreDataSet.Customers);

		}

		private void button2_Click(object sender, EventArgs e)
		{
			Sales sales = new Sales();
			sales.Show();
			this.Hide();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			if (checkBox1.Checked && checkBox2.Checked && checkBox3.Checked && checkBox4.Checked)
			{
				//1
				SqlConnection con = new SqlConnection("Data Source=DESKTOP-BVQ14LQ\\SQLEXPRESS;Initial Catalog=CdStore;Integrated Security=True");

				//2
				string numOfSelctedStorage = "";
				string query = "insert into Sales values('" + listBox1.SelectedValue + "','" + comboBox1.SelectedValue + "','"+dateTimePicker1.Value.ToString("yyyy-MM-dd")+"')";
				string query2="select Storage from Cds where id='"+comboBox1.SelectedValue+"'";
				

				//3
				SqlCommand command = new SqlCommand(query, con);
				SqlCommand command2 = new SqlCommand(query2, con);
				
				//4
				try
				{
					con.Open();

					numOfSelctedStorage = command2.ExecuteScalar().ToString();

					if (Convert.ToInt32(numOfSelctedStorage) >= 5)
					{
						command.ExecuteNonQuery();
						MessageBox.Show("Sale completed successfully");
						numOfSelctedStorage =Convert.ToString(Convert.ToInt32(numOfSelctedStorage) - 1);
						
					}
					else if (Convert.ToInt32(numOfSelctedStorage) >= 1 && Convert.ToInt32(numOfSelctedStorage) <= 4)
					{
						command.ExecuteNonQuery();
						MessageBox.Show("Storage is running low for this Cd");
						MessageBox.Show("Sale completed successfully");
						numOfSelctedStorage = Convert.ToString(Convert.ToInt32(numOfSelctedStorage) - 1);
						
					}
					else
					{
						MessageBox.Show("The are now available copies of that Cd in the storage");
					}

					//5
					string query3 = "update Cds set Storage='" + numOfSelctedStorage + "' where id='" + comboBox1.SelectedValue + "'";
					
					//6
					SqlCommand command3 = new SqlCommand(query3, con);

					//7
					command3.ExecuteNonQuery();

					con.Close();

				}
				catch (Exception ex)
				{
					con.Close();
					MessageBox.Show(ex.ToString());
				}

			}
			else
			{
				MessageBox.Show("Please follow the right procedure before continuing with the sale");
			}
		}
	}
}
