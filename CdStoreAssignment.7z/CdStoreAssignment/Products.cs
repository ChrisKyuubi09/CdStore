﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CdStoreAssignment
{
	public partial class Products : Form
	{
		public Products()
		{
			InitializeComponent();
		}

		private void Products_Load(object sender, EventArgs e)
		{
			// TODO: This line of code loads data into the 'cdStoreDataSet1.Cds' table. You can move, or remove it, as needed.
			this.cdsTableAdapter.Fill(this.cdStoreDataSet1.Cds);

		}

		private void button4_Click(object sender, EventArgs e)
		{
			Form1 f1 = new Form1();
			f1.Show();
			this.Hide();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			UpdateProductForm upf = new UpdateProductForm();
			upf.Show();
			this.Hide();
		}

		private void button3_Click(object sender, EventArgs e)
		{
			DeleteProductForm dpf = new DeleteProductForm();
			dpf.Show();
			this.Hide();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			InsertProductForm ipf = new InsertProductForm();
			ipf.Show();
			this.Hide();
		}
	}
}
