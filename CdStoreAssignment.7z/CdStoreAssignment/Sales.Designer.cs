﻿namespace CdStoreAssignment
{
	partial class Sales
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.button4 = new System.Windows.Forms.Button();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.button3 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.cdStoreDataSet2 = new CdStoreAssignment.CdStoreDataSet2();
			this.salesViewBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.salesViewTableAdapter = new CdStoreAssignment.CdStoreDataSet2TableAdapters.SalesViewTableAdapter();
			this.cdStoreDataSet3 = new CdStoreAssignment.CdStoreDataSet3();
			this.salesViewBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
			this.salesViewTableAdapter1 = new CdStoreAssignment.CdStoreDataSet3TableAdapters.SalesViewTableAdapter();
			this.cdStoreDataSet4 = new CdStoreAssignment.CdStoreDataSet4();
			this.salesBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.salesTableAdapter = new CdStoreAssignment.CdStoreDataSet4TableAdapters.SalesTableAdapter();
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.button5 = new System.Windows.Forms.Button();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.cdStoreDataSet2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.salesViewBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.cdStoreDataSet3)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.salesViewBindingSource1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.cdStoreDataSet4)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.salesBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			this.SuspendLayout();
			// 
			// button4
			// 
			this.button4.Location = new System.Drawing.Point(12, 394);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(171, 41);
			this.button4.TabIndex = 11;
			this.button4.Text = "< Go Back";
			this.button4.UseVisualStyleBackColor = true;
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.button5);
			this.groupBox1.Controls.Add(this.button3);
			this.groupBox1.Controls.Add(this.button2);
			this.groupBox1.Controls.Add(this.button1);
			this.groupBox1.Location = new System.Drawing.Point(12, 80);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(694, 59);
			this.groupBox1.TabIndex = 10;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Operations";
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(347, 19);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(164, 33);
			this.button3.TabIndex = 2;
			this.button3.Text = "Delete";
			this.button3.UseVisualStyleBackColor = true;
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(177, 19);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(164, 33);
			this.button2.TabIndex = 1;
			this.button2.Text = "Update";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(7, 20);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(164, 33);
			this.button1.TabIndex = 0;
			this.button1.Text = "New Sale";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Comic Sans MS", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(218, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(314, 49);
			this.label1.TabIndex = 9;
			this.label1.Text = "Sales Managment";
			// 
			// cdStoreDataSet2
			// 
			this.cdStoreDataSet2.DataSetName = "CdStoreDataSet2";
			this.cdStoreDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			// 
			// salesViewBindingSource
			// 
			this.salesViewBindingSource.DataMember = "SalesView";
			this.salesViewBindingSource.DataSource = this.cdStoreDataSet2;
			// 
			// salesViewTableAdapter
			// 
			this.salesViewTableAdapter.ClearBeforeFill = true;
			// 
			// cdStoreDataSet3
			// 
			this.cdStoreDataSet3.DataSetName = "CdStoreDataSet3";
			this.cdStoreDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			// 
			// salesViewBindingSource1
			// 
			this.salesViewBindingSource1.DataMember = "SalesView";
			this.salesViewBindingSource1.DataSource = this.cdStoreDataSet3;
			// 
			// salesViewTableAdapter1
			// 
			this.salesViewTableAdapter1.ClearBeforeFill = true;
			// 
			// cdStoreDataSet4
			// 
			this.cdStoreDataSet4.DataSetName = "CdStoreDataSet4";
			this.cdStoreDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			// 
			// salesBindingSource
			// 
			this.salesBindingSource.DataMember = "Sales";
			this.salesBindingSource.DataSource = this.cdStoreDataSet4;
			// 
			// salesTableAdapter
			// 
			this.salesTableAdapter.ClearBeforeFill = true;
			// 
			// dataGridView1
			// 
			this.dataGridView1.AllowUserToAddRows = false;
			this.dataGridView1.AllowUserToDeleteRows = false;
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Location = new System.Drawing.Point(12, 157);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.ReadOnly = true;
			this.dataGridView1.Size = new System.Drawing.Size(763, 214);
			this.dataGridView1.TabIndex = 12;
			// 
			// button5
			// 
			this.button5.Location = new System.Drawing.Point(517, 19);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(164, 33);
			this.button5.TabIndex = 3;
			this.button5.Text = "Search By Date";
			this.button5.UseVisualStyleBackColor = true;
			this.button5.Click += new System.EventHandler(this.button5_Click);
			// 
			// Sales
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(787, 450);
			this.Controls.Add(this.dataGridView1);
			this.Controls.Add(this.button4);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.label1);
			this.Name = "Sales";
			this.Text = "Sales";
			this.Load += new System.EventHandler(this.Sales_Load);
			this.groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.cdStoreDataSet2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.salesViewBindingSource)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.cdStoreDataSet3)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.salesViewBindingSource1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.cdStoreDataSet4)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.salesBindingSource)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label1;
		private CdStoreDataSet2 cdStoreDataSet2;
		private System.Windows.Forms.BindingSource salesViewBindingSource;
		private CdStoreDataSet2TableAdapters.SalesViewTableAdapter salesViewTableAdapter;
		private CdStoreDataSet3 cdStoreDataSet3;
		private System.Windows.Forms.BindingSource salesViewBindingSource1;
		private CdStoreDataSet3TableAdapters.SalesViewTableAdapter salesViewTableAdapter1;
		private CdStoreDataSet4 cdStoreDataSet4;
		private System.Windows.Forms.BindingSource salesBindingSource;
		private CdStoreDataSet4TableAdapters.SalesTableAdapter salesTableAdapter;
		private System.Windows.Forms.DataGridView dataGridView1;
		private System.Windows.Forms.Button button5;
	}
}