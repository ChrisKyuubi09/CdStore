﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CdStoreAssignment
{
	public partial class UpdateCustomerForm : Form
	{
		public UpdateCustomerForm()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			//Step 1
			SqlConnection con = new SqlConnection("Data Source=DESKTOP-BVQ14LQ\\SQLEXPRESS;Initial Catalog=CdStore;Integrated Security=True");
			//Step2
			string query = "update Customers set Name='" + textBox1.Text + "',Surname='"+textBox2.Text+"',FavoriteBand='"+textBox3.Text+"',Email='"+textBox4.Text+"',Phone='"+textBox5.Text+"' ";
			//Step3
			SqlCommand command = new SqlCommand(query, con);
			//Step4
			try
			{
				con.Open();

				if (command.ExecuteNonQuery() > 0)
				{
					MessageBox.Show("Customer's info updated successfully");
				}
				else
				{
					MessageBox.Show("Customer not found");
				}

				con.Close();
			}
			catch (Exception ex)
			{
				con.Close();
				MessageBox.Show(ex.ToString());
			}
		}

		private void button2_Click(object sender, EventArgs e)
		{
			Customers cus = new Customers();
			cus.Show();
			this.Hide();
		}
	}
}
