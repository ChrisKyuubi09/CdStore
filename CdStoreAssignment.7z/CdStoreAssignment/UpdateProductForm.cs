﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CdStoreAssignment
{
	public partial class UpdateProductForm : Form
	{
		public UpdateProductForm()
		{
			InitializeComponent();
		}

		private void UpdateProductForm_Load(object sender, EventArgs e)
		{
			// TODO: This line of code loads data into the 'cdStoreDataSet1.Cds' table. You can move, or remove it, as needed.
			this.cdsTableAdapter.Fill(this.cdStoreDataSet1.Cds);

		}

		private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
		{

		}

		private void label7_Click(object sender, EventArgs e)
		{

		}

		private void button2_Click(object sender, EventArgs e)
		{
			Products p = new Products();
			p.Show();
			this.Hide();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			SqlConnection con = new SqlConnection("Data Source=DESKTOP-BVQ14LQ\\SQLEXPRESS;Initial Catalog=CdStore;Integrated Security=True");

			string gerneSelect = comboBox2.SelectedItem.ToString();
			string query = "update Cds set singer='" + textBox2.Text + "',gerne='" + gerneSelect + "',price='"+textBox4.Text+"',storage='"+textBox5.Text+"' where id='"+comboBox1.SelectedValue+"'";
			
			SqlCommand command = new SqlCommand(query, con);

			try 
			{
				con.Open();

				command.ExecuteNonQuery();
				MessageBox.Show("Update record was successfull");

				con.Close();
			}
			catch (Exception ex)
			{
				con.Close();
				MessageBox.Show(ex.ToString());
			}
		}
	}
}
