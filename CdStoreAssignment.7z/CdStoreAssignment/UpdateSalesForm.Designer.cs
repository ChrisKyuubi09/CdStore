﻿namespace CdStoreAssignment
{
	partial class UpdateSalesForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.label4 = new System.Windows.Forms.Label();
			this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.label3 = new System.Windows.Forms.Label();
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.label2 = new System.Windows.Forms.Label();
			this.button2 = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.cdStoreDataSet = new CdStoreAssignment.CdStoreDataSet();
			this.customersBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.customersTableAdapter = new CdStoreAssignment.CdStoreDataSetTableAdapters.CustomersTableAdapter();
			this.cdStoreDataSet1 = new CdStoreAssignment.CdStoreDataSet1();
			this.cdsBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.cdsTableAdapter = new CdStoreAssignment.CdStoreDataSet1TableAdapters.CdsTableAdapter();
			((System.ComponentModel.ISupportInitialize)(this.cdStoreDataSet)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.cdStoreDataSet1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.cdsBindingSource)).BeginInit();
			this.SuspendLayout();
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(18, 199);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(30, 13);
			this.label4.TabIndex = 28;
			this.label4.Text = "Date";
			// 
			// dateTimePicker1
			// 
			this.dateTimePicker1.Location = new System.Drawing.Point(21, 215);
			this.dateTimePicker1.Name = "dateTimePicker1";
			this.dateTimePicker1.Size = new System.Drawing.Size(253, 20);
			this.dateTimePicker1.TabIndex = 27;
			// 
			// comboBox1
			// 
			this.comboBox1.DataSource = this.cdsBindingSource;
			this.comboBox1.DisplayMember = "Album";
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Location = new System.Drawing.Point(21, 175);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(253, 21);
			this.comboBox1.TabIndex = 25;
			this.comboBox1.ValueMember = "Id";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(18, 159);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(54, 13);
			this.label3.TabIndex = 24;
			this.label3.Text = "Cd/Album";
			// 
			// listBox1
			// 
			this.listBox1.DataSource = this.customersBindingSource;
			this.listBox1.DisplayMember = "Name";
			this.listBox1.FormattingEnabled = true;
			this.listBox1.Location = new System.Drawing.Point(21, 91);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new System.Drawing.Size(253, 56);
			this.listBox1.TabIndex = 23;
			this.listBox1.ValueMember = "Id";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(18, 75);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(75, 13);
			this.label2.TabIndex = 22;
			this.label2.Text = "Customers List";
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(21, 330);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(102, 51);
			this.button2.TabIndex = 21;
			this.button2.Text = "< Go Back";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(21, 260);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(262, 45);
			this.button1.TabIndex = 20;
			this.button1.Text = "Update Record";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Comic Sans MS", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.Black;
			this.label1.Location = new System.Drawing.Point(12, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(384, 49);
			this.label1.TabIndex = 19;
			this.label1.Text = "Update a sale record";
			// 
			// cdStoreDataSet
			// 
			this.cdStoreDataSet.DataSetName = "CdStoreDataSet";
			this.cdStoreDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			// 
			// customersBindingSource
			// 
			this.customersBindingSource.DataMember = "Customers";
			this.customersBindingSource.DataSource = this.cdStoreDataSet;
			// 
			// customersTableAdapter
			// 
			this.customersTableAdapter.ClearBeforeFill = true;
			// 
			// cdStoreDataSet1
			// 
			this.cdStoreDataSet1.DataSetName = "CdStoreDataSet1";
			this.cdStoreDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			// 
			// cdsBindingSource
			// 
			this.cdsBindingSource.DataMember = "Cds";
			this.cdsBindingSource.DataSource = this.cdStoreDataSet1;
			// 
			// cdsTableAdapter
			// 
			this.cdsTableAdapter.ClearBeforeFill = true;
			// 
			// UpdateSalesForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(392, 387);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.dateTimePicker1);
			this.Controls.Add(this.comboBox1);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.listBox1);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.label1);
			this.Name = "UpdateSalesForm";
			this.Text = "UpdateSalesForm";
			this.Load += new System.EventHandler(this.UpdateSalesForm_Load);
			((System.ComponentModel.ISupportInitialize)(this.cdStoreDataSet)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.customersBindingSource)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.cdStoreDataSet1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.cdsBindingSource)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.DateTimePicker dateTimePicker1;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ListBox listBox1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label1;
		private CdStoreDataSet cdStoreDataSet;
		private System.Windows.Forms.BindingSource customersBindingSource;
		private CdStoreDataSetTableAdapters.CustomersTableAdapter customersTableAdapter;
		private CdStoreDataSet1 cdStoreDataSet1;
		private System.Windows.Forms.BindingSource cdsBindingSource;
		private CdStoreDataSet1TableAdapters.CdsTableAdapter cdsTableAdapter;
	}
}