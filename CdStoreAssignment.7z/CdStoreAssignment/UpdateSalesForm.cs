﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CdStoreAssignment
{
	public partial class UpdateSalesForm : Form
	{
		public UpdateSalesForm()
		{
			InitializeComponent();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			Sales s = new Sales();
			s.Show();
			this.Hide();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			//Step 1
			SqlConnection con = new SqlConnection("Data Source=DESKTOP-BVQ14LQ\\SQLEXPRESS;Initial Catalog=CdStore;Integrated Security=True");
			//Step2
			string query = "update Sales set idCd='"+comboBox1.SelectedValue+"',saleDate='"+dateTimePicker1.Value.ToString("yyyy-MM-dd")+"' where idCustomer='"+listBox1.SelectedValue+"'";
			//3
			SqlCommand command = new SqlCommand(query, con);
			//Step4
			try
			{
				con.Open();

				if (command.ExecuteNonQuery() > 0)
				{
					MessageBox.Show("Sales record updated successfully");
				}
				else
				{
					MessageBox.Show("Sales record not found");
				}

				con.Close();
			}
			catch (Exception ex)
			{
				con.Close();
				MessageBox.Show(ex.ToString());
			}
		}

		private void UpdateSalesForm_Load(object sender, EventArgs e)
		{
			// TODO: This line of code loads data into the 'cdStoreDataSet1.Cds' table. You can move, or remove it, as needed.
			this.cdsTableAdapter.Fill(this.cdStoreDataSet1.Cds);
			// TODO: This line of code loads data into the 'cdStoreDataSet.Customers' table. You can move, or remove it, as needed.
			this.customersTableAdapter.Fill(this.cdStoreDataSet.Customers);

		}
	}
}
